"""
Run this script ONCE to upload your college data to Azure Cognitive Search.
Before running: fill in your AZURE_SEARCH_ENDPOINT and AZURE_SEARCH_KEY below.
"""

from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex, SimpleField, SearchableField, SearchFieldDataType
)
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential

# ── Fill these in ──────────────────────────────────────────────
SEARCH_ENDPOINT = "https://YOUR_SEARCH_NAME.search.windows.net"
SEARCH_KEY      = "YOUR_SEARCH_ADMIN_KEY"
INDEX_NAME      = "college-knowledge"

# ── Create Index ───────────────────────────────────────────────
index_client = SearchIndexClient(SEARCH_ENDPOINT, AzureKeyCredential(SEARCH_KEY))

fields = [
    SimpleField(name="id",       type=SearchFieldDataType.String, key=True),
    SearchableField(name="title",   type=SearchFieldDataType.String),
    SearchableField(name="content", type=SearchFieldDataType.String),
    SimpleField(name="category", type=SearchFieldDataType.String, filterable=True),
]

index = SearchIndex(name=INDEX_NAME, fields=fields)
index_client.create_or_update_index(index)
print("✅ Index created!")

# ── Upload College Data ────────────────────────────────────────
search_client = SearchClient(SEARCH_ENDPOINT, INDEX_NAME, AzureKeyCredential(SEARCH_KEY))

college_data = [
    {
        "id": "1",
        "title": "Admission Process",
        "category": "admissions",
        "content": (
            "Admissions open every June. Apply via the college portal at admissions.college.edu. "
            "Required documents: 10th and 12th marksheets, transfer certificate, government ID proof, "
            "and two passport-size photos. Last date to apply is July 31. "
            "Lateral entry available for diploma holders in B.Tech programs."
        )
    },
    {
        "id": "2",
        "title": "Fee Structure",
        "category": "fees",
        "content": (
            "Annual fee structure for 2024-25: "
            "B.Tech: Rs.85,000 per year. MBA: Rs.1,20,000 per year. "
            "MCA: Rs.70,000 per year. BCA and B.Sc: Rs.45,000 per year. "
            "Hostel fee: Rs.45,000 per year. "
            "Merit scholarships available up to 100% for top-ranking students. "
            "Fee payment accepted online via the student portal."
        )
    },
    {
        "id": "3",
        "title": "Courses Offered",
        "category": "academics",
        "content": (
            "Undergraduate programs: B.Tech in Computer Science, Electronics and Communication, "
            "Mechanical Engineering, and Civil Engineering. BCA and B.Sc in Physics, Chemistry, Mathematics. "
            "Postgraduate programs: MBA, MCA, M.Tech. "
            "All programs approved by AICTE and affiliated to the State University."
        )
    },
    {
        "id": "4",
        "title": "Campus Facilities",
        "category": "campus",
        "content": (
            "Central library open from 7AM to 10PM with over 50,000 books and digital resources. "
            "High-speed Wi-Fi across the entire 50-acre campus. "
            "Sports complex with cricket ground, basketball court, and indoor badminton. "
            "Fully equipped gym, cafeteria, ATM, and medical center on campus. "
            "Boys and girls hostels with 24/7 security and CCTV surveillance."
        )
    },
    {
        "id": "5",
        "title": "Exam Schedule and Results",
        "category": "exams",
        "content": (
            "Semester exams held in November and May every year. "
            "Internal assessment exams conducted every 6 weeks. "
            "Hall tickets issued 10 days before the exam. "
            "Results published within 30 days on the student portal at results.college.edu. "
            "Re-valuation requests accepted within 15 days of result publication."
        )
    },
    {
        "id": "6",
        "title": "Placement Cell",
        "category": "placements",
        "content": (
            "Placement drives conducted from September to March every year. "
            "2023-24 statistics: 92% placement rate, average package Rs.6.5 LPA, highest package Rs.18 LPA. "
            "Top recruiters: TCS, Infosys, Wipro, Cognizant, Amazon, Zoho, HCL, and Capgemini. "
            "Dedicated placement training program from third year onwards including aptitude, "
            "soft skills, and mock interviews."
        )
    },
    {
        "id": "7",
        "title": "Contact Information",
        "category": "contact",
        "content": (
            "Main office contact: +91-422-XXXXXXXX. "
            "Admissions office: admissions@college.edu. "
            "General enquiries: info@college.edu. "
            "Office hours: Monday to Saturday, 9AM to 5PM. "
            "Address: NH-47, College Road, Coimbatore, Tamil Nadu - 641XXX."
        )
    },
    {
        "id": "8",
        "title": "Scholarships",
        "category": "fees",
        "content": (
            "Merit scholarship: 100% fee waiver for students scoring above 95% in 12th standard. "
            "Sports quota: 50% fee concession for state and national level sportspersons. "
            "SC/ST scholarship: Government of India scholarship applicable, fully supported. "
            "Management scholarship: 25% fee concession for economically weaker students. "
            "Apply for scholarships at the time of admission with supporting documents."
        )
    },
    {
        "id": "9",
        "title": "Anti-Ragging Policy",
        "category": "campus",
        "content": (
            "The college has a strict zero-tolerance anti-ragging policy. "
            "Anti-ragging committee available 24/7. Helpline: 1800-XXX-XXXX. "
            "All incidents are investigated and strict action taken. "
            "Students can report anonymously via the college portal."
        )
    },
    {
        "id": "10",
        "title": "Transport Facilities",
        "category": "campus",
        "content": (
            "College buses operate on 15 routes covering major areas of the city and surrounding towns. "
            "Bus pass available at Rs.8,000 per year. "
            "Pick-up and drop timings: 7:30AM and 5:30PM on weekdays. "
            "Contact the transport office for route details: transport@college.edu."
        )
    },
]

result = search_client.upload_documents(documents=college_data)
print(f"✅ Uploaded {len(college_data)} documents to Azure Cognitive Search!")
print("You can now run your chatbot and it will answer questions using this data.")
