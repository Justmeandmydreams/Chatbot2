# College Chatbot — Azure AI

An AI-powered college assistant chatbot built with FastAPI and Microsoft Azure services.

## Files in this Repository

| File | Purpose |
|------|---------|
| `main.py` | FastAPI backend — handles chat API |
| `requirements.txt` | Python dependencies |
| `startup.txt` | Azure App Service startup command |
| `.env.example` | Environment variable template |
| `setup_knowledge_base.py` | One-time script to upload college data to Azure Search |
| `static/index.html` | Frontend chat interface |

## Azure Services Used

- Azure OpenAI (GPT-4)
- Azure Cognitive Search
- Azure Cosmos DB
- Azure App Service

## Setup Steps

### 1. Add Environment Variables in Azure Portal
Go to your App Service → Configuration → Application Settings and add:

```
AZURE_OPENAI_ENDPOINT = https://your-openai.openai.azure.com/
AZURE_OPENAI_KEY      = your_key
AZURE_OPENAI_DEPLOYMENT = gpt-4
AZURE_SEARCH_ENDPOINT = https://your-search.search.windows.net
AZURE_SEARCH_KEY      = your_key
COSMOS_ENDPOINT       = https://your-cosmos.documents.azure.com:443/
COSMOS_KEY            = your_key
```

### 2. Set Startup Command in Azure Portal
Go to App Service → Configuration → General Settings → Startup Command:
```
uvicorn main:app --host 0.0.0.0 --port 8000
```

### 3. Run Knowledge Base Setup (once)
Fill in your credentials in `setup_knowledge_base.py` and run it once to upload college data.

### 4. Deploy via GitHub
Connect this repo in App Service → Deployment Center → GitHub.
